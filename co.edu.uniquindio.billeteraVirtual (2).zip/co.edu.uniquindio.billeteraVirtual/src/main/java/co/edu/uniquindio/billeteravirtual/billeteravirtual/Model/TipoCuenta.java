package co.edu.uniquindio.billeteravirtual.billeteravirtual.Model;

public enum TipoCuenta {
    AHORROS,
    CORRIENTE
}
