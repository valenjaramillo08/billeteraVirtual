package co.edu.uniquindio.billeteravirtual.billeteravirtual.Model;

public enum TipoTransaccion {
    RETIRO,
    TRANSFERENCIA,
    DEPOSITO
}
