package co.edu.uniquindio.billeteravirtual.billeteravirtual.Command;

public interface Command{
    void execute();
}