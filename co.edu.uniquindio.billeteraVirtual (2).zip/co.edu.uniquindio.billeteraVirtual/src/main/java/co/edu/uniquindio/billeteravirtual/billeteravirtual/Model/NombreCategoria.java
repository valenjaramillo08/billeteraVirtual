package co.edu.uniquindio.billeteravirtual.billeteravirtual.Model;

public enum NombreCategoria {
    COMIDA,
    UNIVERSIDAD,
    TRANSPORTE,
    HOGAR,
    OCIO,
    OTROS
}
