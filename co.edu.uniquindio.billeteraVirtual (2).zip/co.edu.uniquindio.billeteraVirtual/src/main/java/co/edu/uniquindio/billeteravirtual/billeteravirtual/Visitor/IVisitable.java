package co.edu.uniquindio.billeteravirtual.billeteravirtual.Visitor;

public interface IVisitable {
    void aceptar(IVisitor visitor);


}
