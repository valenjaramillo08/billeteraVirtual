package co.edu.uniquindio.billeteravirtual.billeteravirtual.Decorator;

public interface TransaccionD {
    void ejecutar();
    
}
