package co.edu.uniquindio.billeteravirtual.billeteravirtual.Observador;

public interface ObservadorAdministrador {
    void actualizarUsuarios();
}
