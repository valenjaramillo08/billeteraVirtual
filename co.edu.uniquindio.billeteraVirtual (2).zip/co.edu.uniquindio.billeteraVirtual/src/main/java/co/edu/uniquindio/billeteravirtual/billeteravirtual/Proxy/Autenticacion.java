package co.edu.uniquindio.billeteravirtual.billeteravirtual.Proxy;

public interface Autenticacion {
    boolean autenticar(String id, String clave);
}
