package co.edu.uniquindio.billeteravirtual.billeteravirtual.Observador;


import co.edu.uniquindio.billeteravirtual.billeteravirtual.Model.Presupuesto;

public interface Observador {
    void actualizar(Presupuesto presupuesto);
}
