package co.edu.uniquindio.billeteravirtual.billeteravirtual.Service;

public interface IVisitable {
    void aceptar(IVisitor visitor);


}
