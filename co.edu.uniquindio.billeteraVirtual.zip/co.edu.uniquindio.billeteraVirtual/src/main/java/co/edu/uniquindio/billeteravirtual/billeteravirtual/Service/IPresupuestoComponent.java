package co.edu.uniquindio.billeteravirtual.billeteravirtual.Service;

public interface IPresupuestoComponent {
    double getMontoPresupuesto();
    double getMontoPresupuestoGastado();
    String getNombrePresupuesto();
    void mostrar();
}
