package co.edu.uniquindio.billeteravirtual.billeteravirtual.Service;

public interface IObservadorSaldo {
    void actualizar(double nuevoSaldo);

}
