package co.edu.uniquindio.billeteravirtual.billeteravirtual.Model;

public enum TipoCuentaOrigen {
    AHORROS,
    CORRIENTE
}
