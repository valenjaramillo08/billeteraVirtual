package co.edu.uniquindio.billeteravirtual.billeteravirtual.Mapping.Dto;

public record UsuarioDto(
    String nombre,
    String apellido,
    String idUsuario,
    String correo
){

}

